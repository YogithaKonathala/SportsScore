package com.example.yogi.sportsscore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3;
    TextView tv;
    int ic=0,pc=0,tc=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.btn1);

        b2=findViewById(R.id.btn2);
        b3=findViewById(R.id.btn3);
        tv=findViewById(R.id.tv1);

    }

    public void onPakistan(View view) {
        pc++;
        //tv.setText("Pakistan score :"+pc);

    }

    public void onIndia(View view) {
        ic++;
        //tv.setText("India Score is:"+ic);

    }
    public void onScore(View view){
        if(ic>pc){
            tv.setText("Highest Score :India with"+ic);
        }
        else
            tv.setText("Highest Score :Pakistan with"+pc);



        }
}
